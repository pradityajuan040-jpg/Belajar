using System.Data.Entity;
using ConsoleApp3.Entitas;

namespace ConsoleApp3.Data
{
    public class KampusContext : DbContext
    {
        public KampusContext() : base("name=KoneksiDb") { }

        public DbSet<Mahasiswa> Mahasiswas { get; set; }
        public DbSet<Prodi> Prodis { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Mahasiswa>().HasKey(m => m.Nim);
            modelBuilder.Entity<Prodi>().HasKey(p => p.KodeProdi);
            modelBuilder.Entity<Mahasiswa>().Ignore(m => m.StrJk);
            base.OnModelCreating(modelBuilder);
        }
    }
}
