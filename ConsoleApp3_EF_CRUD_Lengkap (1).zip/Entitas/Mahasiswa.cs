using System.ComponentModel.DataAnnotations;

namespace ConsoleApp3.Entitas
{
    public class Mahasiswa
    {
        [Key]
        public string Nim { get; set; }
        public string Nama { get; set; }
        public string JenisKelamin { get; set; }
        public string KodeProdi { get; set; }

        public string StrJk
        {
            get { return JenisKelamin == "L" ? "Laki-laki" : "Perempuan"; }
        }
    }
}
