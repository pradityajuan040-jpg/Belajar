using System.ComponentModel.DataAnnotations;

namespace ConsoleApp3.Entitas
{
    public class Prodi
    {
        [Key]
        public string KodeProdi { get; set; }
        public string NamaProdi { get; set; }
    }
}
