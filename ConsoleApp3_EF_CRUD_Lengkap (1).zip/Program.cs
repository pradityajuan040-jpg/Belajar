using System;
using System.Linq;
using ConsoleApp3.Data;
using ConsoleApp3.Entitas;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new KampusContext())
            {
                int pilih;
                do
                {
                    Console.Clear();
                    Console.WriteLine("=== MENU MAHASISWA (EF) ===");
                    Console.WriteLine("1. Tambah Mahasiswa");
                    Console.WriteLine("2. Lihat Mahasiswa");
                    Console.WriteLine("3. Update Mahasiswa");
                    Console.WriteLine("4. Hapus Mahasiswa");
                    Console.WriteLine("0. Keluar");
                    Console.Write("Pilih: ");
                    pilih = int.Parse(Console.ReadLine());

                    switch (pilih)
                    {
                        case 1:
                            Tambah(context);
                            break;
                        case 2:
                            Tampil(context);
                            break;
                        case 3:
                            Update(context);
                            break;
                        case 4:
                            Hapus(context);
                            break;
                    }

                } while (pilih != 0);
            }
        }

        static void Tambah(KampusContext context)
        {
            Console.Write("NIM: ");
            string nim = Console.ReadLine();

            if (context.Mahasiswas.Find(nim) != null)
            {
                Console.WriteLine("Mahasiswa sudah ada");
                Console.ReadKey();
                return;
            }

            Console.Write("Nama: ");
            string nama = Console.ReadLine();

            Console.Write("JK (L/P): ");
            string jk = Console.ReadLine();

            var prodi = context.Prodis.Find("TI");
            if (prodi == null)
            {
                context.Prodis.Add(new Prodi { KodeProdi = "TI", NamaProdi = "Teknik Informatika" });
            }

            context.Mahasiswas.Add(new Mahasiswa
            {
                Nim = nim,
                Nama = nama,
                JenisKelamin = jk,
                KodeProdi = "TI"
            });

            context.SaveChanges();
            Console.WriteLine("Data berhasil ditambah");
            Console.ReadKey();
        }

        static void Tampil(KampusContext context)
        {
            Console.WriteLine("=== DATA MAHASISWA ===");
            foreach (var m in context.Mahasiswas.ToList())
            {
                Console.WriteLine($"{m.Nim} | {m.Nama} | {m.StrJk} | {m.KodeProdi}");
            }
            Console.ReadKey();
        }

        static void Update(KampusContext context)
        {
            Console.Write("NIM yang diupdate: ");
            string nim = Console.ReadLine();
            var m = context.Mahasiswas.Find(nim);

            if (m == null)
            {
                Console.WriteLine("Data tidak ditemukan");
                Console.ReadKey();
                return;
            }

            Console.Write("Nama baru: ");
            m.Nama = Console.ReadLine();

            context.SaveChanges();
            Console.WriteLine("Data berhasil diupdate");
            Console.ReadKey();
        }

        static void Hapus(KampusContext context)
        {
            Console.Write("NIM yang dihapus: ");
            string nim = Console.ReadLine();
            var m = context.Mahasiswas.Find(nim);

            if (m == null)
            {
                Console.WriteLine("Data tidak ditemukan");
                Console.ReadKey();
                return;
            }

            context.Mahasiswas.Remove(m);
            context.SaveChanges();
            Console.WriteLine("Data berhasil dihapus");
            Console.ReadKey();
        }
    }
}
